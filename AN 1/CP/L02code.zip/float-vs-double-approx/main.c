#include <stdio.h>
#include <stdlib.h>

int main()
{
    float f=0.1;
    double d=0.1;

    printf("%17.1f\n", 213212313421234112.0f * f);
    printf("%17.1f\n", 213212313421234112.0 * d);
    return 0;
}
