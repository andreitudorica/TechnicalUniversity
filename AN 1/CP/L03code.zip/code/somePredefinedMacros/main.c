#include <stdio.h>
#include <stdlib.h>
#define DEBUG

int main()
{
    #ifdef DEBUG
        printf("%s\n", __FILE__);
        printf("%s\n", __FUNCTION__);
        printf("%d\n", __LINE__);
    #else
        printf("Hello world\n");
    #endif
    return 0;
}
