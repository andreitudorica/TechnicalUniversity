#include <stdio.h>
#include <stdlib.h>
#undef __STRICT_ANSI__
#include <math.h>
/* Compute intensity and phase shift in a serial circuit */
int main(int argc, char *argv[])
{
  	double V, R, L, f, Z, XL, I, phi;
	printf("\nEffective voltage, V= "); 	scanf("%lf", &V);
	printf("\nResistance in Ohms, R= ");	scanf("%lf", &R);
	printf("\nInductance in Henry, L= ");	scanf("%lf", &L);
	printf("\nFrequency in Hertz, f= ");	scanf("%lf", &f);
	XL = 2 * M_PI * f * L;  /* inductance reactance */
	Z = sqrt(R * R + XL *XL); /* impedance */
	I = V / Z; /* intensity in Amperes */
	phi = atan( XL / R ) * 180 / M_PI; /* phase shift in sexagesimal degrees */
	printf("\nIntensity I=%6.3f (Amperes)", I);
	printf("\nPhase shift phi=%6.3f (degrees)\n", phi);
  	system("PAUSE");
  	return 0;
}
