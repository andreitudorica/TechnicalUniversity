#define SWAP(vartype, a, b) (vartype t;\
			t=a; a=b; b=t; ) 
			SWAP(int, x, y)
	 SWAP(double, u, v)
