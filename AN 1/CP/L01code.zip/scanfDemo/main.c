#include <stdio.h>
#include <stdlib.h>

int main()
{
    char s[1024];
    printf("*** scanf %%s demo ***\n================================================\n\n");
    sscanf("A string with spaces", "%s", s);
    printf("sscanf(\"A string with spaces\", \"%%s\", s);\n");
    printf("s=%s [with %%s scanf reads up to first whitespace]\n\n", s);

    sscanf("A\tstring\twith\tspaces", "%s", s);
    printf("sscanf(\"A\tstring\twith\tspaces\", \"%%s\", s);\n");
    printf("s=%s [with %%s scanf reads up to first whitespace -- \\t here]\n\n", s);
    sscanf("A_string_without_spaces", "%s", s);
    printf("sscanf(\"A_string_without_spaces\", \"%%s\", s);\n\n");

    printf("s=%s [whole string read]\n", s);
    sscanf("A_string_without_spaces", "%12s", s);
    printf("sscanf(\"A_string_without_spaces\", \"%%12s\", s);\n");
    printf("s=%s [12 characters read]\n\n", s);
    puts("================================================\n");

    printf("*** Using a scan set to read a name of up to 64 characters ***\n================================================\n\n");
    sscanf("Ionescu V. Alexandru-Vasile,80 ani", "%64[-A-Za-z. ]", s);
    printf("sscanf(\"Ionescu V. Alexandru-Vasile 80 ani\", \"%64[-A-Za-z. ]\", s);\n");
    printf("s=%s\n\t[Note that:\n\t\t1. Only the name was read\n\t\t2. The hyphen is at the front of the scan set]\n\n", s);
    puts("================================================\n");



    return 0;
}
