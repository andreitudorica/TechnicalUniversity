#include <stdio.h>
#include <stdlib.h>

int main()
{
    double aDouble=0;
    float aFloat=0;

    for (int i=1; i <= 200000000; i++)
    {
        aDouble += 0.2;
        aFloat += 0.2;
    }

    printf("dbl=%f [%f] flt=%f [%f]\n", aDouble, (double)0.2*200000000, aFloat, (float)0.2*200000000);
    return 0;
}
