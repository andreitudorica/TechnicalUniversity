#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct cell
{
    char key[100];
    struct cell *next;
} nodeT;

#define B 30
nodeT *bucketTable[B];

void initialize_bucket_table()
{
    int i;
    for(i=0;i<=B;i++)
        bucketTable[i]=NULL;
}

int hash_function(char *key)
{
    return strlen(key);
}

nodeT *search_in_bucket_table( char *key)
{ int h;
nodeT *p;
h=hash_function(key);
p=bucketTable[h];
while(p!=NULL)
   {
    if (strcmp(key,p->key)==0)
    return p;
    p=p->next;
   }
   return NULL;
}



void insert_new_node( char *key)
{   int h;
    nodeT *p,*q;
    p=(nodeT*)malloc(sizeof(nodeT));
    if(p)
    {
      strcpy(p->key,key);
      h=hash_function(key);
      if(bucketTable[h]==NULL)
      {
          bucketTable[h]=p;
          p->next=NULL;
      }
      else
      { q=search_in_bucket_table(key);
       if(q==NULL)
       {
        p->next=bucketTable[h];
        bucketTable[h]=p;
       }

      }
    }
}

void show_node(nodeT *p)
{
 printf("%s \n",p->key);
}

void show_table()
{
    int i;
    nodeT *p;
    for(i=0;i<B;i++)
        if(bucketTable[i]!=NULL)
    { printf("Bucket of hash value %d is ",i);
    p=bucketTable[i];
    while(p!=NULL)
    {
        show_node(p);
        p=p->next;
    }
    }

}

nodeT *delete_node(char *key)
{   int h;
    nodeT *p;
    h=hash_function(key);
    p=bucketTable[h];
     if(p!=NULL)
    {
        if(strcmp(p->key,key)==0)//daca e chiar capul listei
            {
                bucketTable[h]=p->next;
                free(p);
            }
         else
         {
             nodeT *q;
             while(p!=NULL && strcmp(p->key,key)!=0)
             { q=p;
               p=p->next;
             }
             if(p!=NULL)
             {
                 q=p->next;
                 free(p);
             }
         }
    }
}

int main()
{   char c,name[30];
    FILE *f;
    f=fopen("date.txt","r");
    if(f==NULL)
    {
        printf("Cannot open the file");
        exit(1);
    }
    while(!feof(f))
    { fscanf(f,"%c",&c);
      if(c=='i')
      {
        fgets(name,sizeof(name),f);
        insert_new_node(name);
      }
      else
      if(c=='f')
      { fgets(name,sizeof(name),f);
          nodeT *p;
          p=search_in_bucket_table(name);
          if(p==NULL)
            printf("Not found.\n");
          else
          {   int h;
              h=hash_function(name);
              printf("Yes , found. Index:%d \n",h);
          }
      }
          else
            if(c=='d')
            {
                fgets(name,sizeof(name),f);
                delete_node(name);
            }
          else
            if(c=='l')
            show_table();



      }
fclose(f);
}











