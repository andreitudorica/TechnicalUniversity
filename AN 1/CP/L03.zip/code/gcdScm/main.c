#include <stdio.h>
#include <stdlib.h>
/* Compute the greatest common divisor and the
smallest common multiple for two numbers */
int main(int argc, char *argv[])
{
    int a, b, a1, b1, gcd, scm, rem;
    printf("Please input number a=");
    scanf("%d", &a);
    printf("Please input number b=");
    scanf("%d", &b);
    /* find the gcd */
    a1 = a;
    b1 = b;
    while ( (rem =a1 % b1) != 0 )
    {
        a1 = b1;
        b1 = rem;
    }
    gcd = b1;
    scm = a * b / gcd;
    printf("a=%d b=%d gcd(a, b)=%d scm(a, b)=%d\n", a, b, gcd, scm);
    return 0;
}
