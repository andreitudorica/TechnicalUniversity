#include <stdio.h>
#include <stdlib.h>
/* Evaluate a simple arithmetic expression */
int main()
{
    int operand1, operand2, result, divByZero = 0;
	char operation;

	printf("Write an arithmetic expression with integers, without spaces\n");
	scanf("%d%c%d", &operand1, &operation, &operand2);
	switch( operation )
	{
		case '+': result = operand1 + operand2;
							break;
		case '-': result = operand1 - operand2;
							break;
		case '*': result = operand1 * operand2;
							break;
		case '/':
		    if (operand2 != 0)
                result = operand1 / operand2;
            else
                divByZero = 1;
			break;
		default:  exit(1);
	}
	if (divByZero)
        printf("Division by zero\n");
    else
        printf("\n%d %c %d = %d\n", operand1, operation, operand2, result);
  return 0;
}
