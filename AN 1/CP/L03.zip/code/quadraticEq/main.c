#include <stdio.h>
#include <math.h>
/* Calculate the roots of the equation a*x^2+b*x+c=0 */
int main(int argc, char *argv[])
{
  double a, b, c, delta, x1, x2;

	printf("\nPlease input coefficients a, b, c\n");
	scanf("%lf %lf %lf", &a, &b, &c);
	if (a !=0 )
 	{
		delta = b * b - 4 * a * c;
		if ( delta >= 0 )
		{
			x1 = ( - b - sqrt( delta )) / ( 2 * a );
			x2 = ( - b + sqrt( delta )) / ( 2 * a );
			printf("\nEquation has real roots x1=%g and x2=%g\n", x1, x2);
		}
		else
		{
			x1 = - b / ( 2 * a );
			x2 = sqrt( -delta ) / ( 2 * a );
			printf("\nEquation has complex roots x1=%g-j*%g and x2=%g+j*%g\n",
				x1, x2, x1, x2);
		}
	}
	else printf("\nEquation is not of second degree\n");
  return 0;
}
