#include <stdio.h>
#include <stdlib.h>

int main()
{
    char digits[129];

    memset(digits, 'A', sizeof(digits));
    scanf("%128[0-9]", digits);
    return 0;
}
