#include <stdio.h>
#define MAXN 10
/* Function approximation using Lagrange's polynomial */
int main(int argc, char *argv[])
{
    double s, p, x0, x[MAXN], y[MAXN];
    int n, i, j;
    char ch;
    for ( n = 0; n < 1 || n > MAXN; scanf("%d", &n) )
    {
		fflush(stdin);
        printf("\nPlease input the number of points [<%d], n=", MAXN);
    }
    for ( i = 0; i < n; i++ )
    {
        printf("x[%d]=", i+1);
        scanf("%lf", &x[i]);
        printf("y[%d]=", i+1);
        scanf("%lf", &y[i]);
    }
    for ( ch = 'Y'; ch == 'Y' || ch == 'y'; ch = getchar() )
    {
        printf("Please input a value for x0=");
        scanf("%lf%*c", &x0);
        for ( s = 0, i = 0; i < n; i++ )
        {
            p = 1;
            for ( j = 0; j < n; j++ )
                if ( i != j ) p = p * ( x0 - x[j]) / ( x[i] - x[j] );
            s += y[i] * p;
        }
        printf("An approximate value for x0=%f is p0=%f\n", x0, s);
        printf("Continue [Yes=Y/y No=other character]? ");
    }
    return 0;
}
