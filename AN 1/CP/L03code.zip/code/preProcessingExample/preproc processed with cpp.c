# 1 "preproc.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "preproc.c"


   (int t; t=x; x=y; y=t; )
  (double t; t=u; u=v; v=t; )
