#include <stdio.h>
#include <stdlib.h>
/* Evaluate a simple arithmetic expression */
int main()
{
    int operand1, operand2, result, divByZero = 0;
	char operation;
    int numRead = 0;
    do
    {   // validate input
        printf("Write an arithmetic expression with integers, without spaces\n");
        numRead = scanf("%d%c%d", &operand1, &operation, &operand2);
        if (numRead != 3)
        {
            printf ("You must input operand operator operand\n\t where operator is one of + - / *\n");
            fflush(stdin);
        }
        else
        {
            switch (operation)
            {
            case '+': // fall through
            case '-': // fall through
            case '/': // fall through
            case '*':
                break;
            default:
                printf("Operation must be one of + - / *\n");
                numRead = 0;
                break;
            }
        }
    }
	while (numRead != 3);
	switch( operation )
	{
		case '+': result = operand1 + operand2;
							break;
		case '-': result = operand1 - operand2;
							break;
		case '*': result = operand1 * operand2;
							break;
		case '/':
		    if (operand2 != 0)
                result = operand1 / operand2;
            else
                divByZero = 1;
			break;
		default:  exit(1);
	}
	if (divByZero)
        printf("Division by zero\n");
    else
        printf("\n%d %c %d = %d\n", operand1, operation, operand2, result);
  return 0;
}
